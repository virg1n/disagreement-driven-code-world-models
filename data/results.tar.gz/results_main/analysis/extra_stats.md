| statistic | disagree | llm | random | disagree_noreset |
|---|---|---|---|---|
| falsify_rate | 0.948 | 0.466 | 0.459 | 0.833 |
| P(expose | shared error exposable) | 0.065 | 0.274 | 0.215 | 0.135 |
| repeat_rate | 0.324 | 0.091 | 0.113 | 0.311 |
| max_run | 8.062 | 2.250 | 2.625 | 7.688 |
| reset_has_max_raw_H | 0.130 | 0.054 | 0.075 | 0.000 |
| final_fit_best | 0.676 | 0.785 | 0.787 | 0.588 |
| n_consistent_final | 0.188 | 1.125 | 0.375 | 0.000 |
| origin_repair_share | 0.938 | 0.833 | 0.896 | 0.906 |

## Offline re-synthesis (64 histories, 16 samples each)

| policy | best-fit: fit | best-fit: held-out acc | best-fit: acc (changing) | oracle acc | oracle acc (changing) | mean sample acc (changing) |
|---|---|---|---|---|---|---|
| disagree | 0.449 | 0.357 | 0.073 | 0.432 | 0.161 | 0.053 |
| llm | 0.674 | 0.373 | 0.036 | 0.404 | 0.084 | 0.043 |
| random | 0.698 | 0.439 | 0.244 | 0.480 | 0.299 | 0.070 |
| disagree_noreset | 0.441 | 0.394 | 0.051 | 0.440 | 0.152 | 0.051 |

| metric | comparison | mean diff | 95% CI | W/T/L |
|---|---|---|---|---|
| best-fit acc | disagree − llm | -0.016 | [-0.076, +0.039] | 7/3/6 |
| best-fit acc | disagree − random | -0.082 | [-0.197, +0.010] | 5/4/7 |
| best-fit acc | disagree − disagree_noreset | -0.037 | [-0.094, +0.014] | 4/5/7 |
| best-fit acc (chg) | disagree − llm | +0.037 | [-0.010, +0.115] | 4/11/1 |
| best-fit acc (chg) | disagree − random | -0.171 | [-0.379, +0.025] | 4/6/6 |
| best-fit acc (chg) | disagree − disagree_noreset | +0.022 | [-0.049, +0.116] | 3/9/4 |
| oracle acc (chg) | disagree − llm | +0.077 | [-0.032, +0.201] | 8/3/5 |
| oracle acc (chg) | disagree − random | -0.138 | [-0.275, -0.023] | 4/4/8 |
| oracle acc (chg) | disagree − disagree_noreset | +0.009 | [-0.076, +0.109] | 4/5/7 |
| mean sample acc (chg) | disagree − llm | +0.010 | [-0.006, +0.029] | 8/1/7 |
| mean sample acc (chg) | disagree − random | -0.017 | [-0.033, -0.004] | 5/0/11 |
| mean sample acc (chg) | disagree − disagree_noreset | +0.002 | [-0.015, +0.020] | 6/2/8 |
