# Shared wrong assumptions on held-out transitions (final pools, all programs agree and are wrong)


## Error type × action kind, by policy

| group | missed change / move | missed change / click | missed change / noop | hallucinated change / move | hallucinated change / click | hallucinated change / noop | wrong change / move | wrong change / click | wrong change / noop | total |
|---|---|---|---|---|---|---|---|---|---|---|
| disagree | 281 | 106 | 54 | 18 | 6 | 8 | 122 | 67 | 20 | 682 |
| disagree_noreset | 263 | 59 | 79 | 10 | 5 | 0 | 205 | 47 | 19 | 687 |
| llm | 269 | 71 | 117 | 14 | 0 | 0 | 86 | 47 | 0 | 604 |
| random | 190 | 107 | 89 | 25 | 0 | 0 | 60 | 41 | 0 | 512 |

## Error type × action kind, by environment

| group | missed change / move | missed change / click | missed change / noop | hallucinated change / move | hallucinated change / click | hallucinated change / noop | wrong change / move | wrong change / click | wrong change / noop | total |
|---|---|---|---|---|---|---|---|---|---|---|
| disease | 51 | 7 | 0 | 0 | 0 | 0 | 83 | 0 | 0 | 141 |
| egg | 228 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 228 |
| gravity | 123 | 94 | 18 | 0 | 0 | 0 | 35 | 0 | 0 | 270 |
| grow | 204 | 96 | 136 | 0 | 0 | 0 | 33 | 0 | 0 | 469 |
| ice | 184 | 61 | 110 | 5 | 0 | 8 | 137 | 81 | 20 | 606 |
| magnets | 107 | 0 | 0 | 62 | 0 | 0 | 13 | 0 | 0 | 182 |
| paint | 0 | 33 | 0 | 0 | 11 | 0 | 0 | 76 | 0 | 120 |
| wind | 106 | 52 | 75 | 0 | 0 | 0 | 172 | 45 | 19 | 469 |

## Examples


### disease — missed change (predicted nothing happens) — click (7 cases)

- [random s1] action `click 2 10` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,3):a>d`
- [llm s0] action `click 2 10` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,3):a>d`
- [random s0] action `click 2 10` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,3):a>d`

### disease — missed change (predicted nothing happens) — move (51 cases)

- [disagree_noreset s0] action `down` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(6,5):a>.`
- [llm s0] action `left` (first-firing clauses [2])
  - predicted: `no change`
  - actual: `(5,6):.>a (6,6):a>.`
- [random s1] action `left` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(2,3):.>d (3,3):d>.`

### disease — wrong change — move (83 cases)

- [llm s0] action `right` (first-firing clauses [])
  - predicted: `(1,1):d>. (2,1):.>d`
  - actual: `(7,5):a>. (8,5):.>a`
- [disagree_noreset s1] action `up` (first-firing clauses [])
  - predicted: `(2,1):.>d (2,2):d>.`
  - actual: `(8,5):.>a (8,6):a>.`
- [disagree_noreset s1] action `right` (first-firing clauses [])
  - predicted: `(4,2):d>. (5,2):.>d (4,4):d>. (5,4):.>d`
  - actual: `(6,6):a>. (7,6):.>a`

### egg — missed change (predicted nothing happens) — move (228 cases)

- [disagree_noreset s1] action `right` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(7,11):t>. (10,11):.>t (6,12):t>. (11,12):.>t (6,13):t>. (11,13):.>t (6,14):t>. (11,14):.>t (7,15):t>. (10,15):.>t`
- [disagree_noreset s0] action `left` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(5,10):.>t (8,10):t>. (4,11):.>t (9,11):t>. (4,12):.>t (9,12):t>. (4,13):.>t (9,13):t>. (5,14):.>t (8,14):t>.`
- [disagree_noreset s1] action `left` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(5,11):.>t (8,11):t>. (4,12):.>t (9,12):t>. (4,13):.>t (9,13):t>. (4,14):.>t (9,14):t>. (5,15):.>t (8,15):t>.`

### gravity — missed change (predicted nothing happens) — click (94 cases)

- [disagree s1] action `click 15 10` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(15,9):b>. (15,11):.>b`
- [llm s0] action `click 0 7` (first-firing clauses [5])
  - predicted: `no change`
  - actual: `(2,14):b>. (3,14):b>.`
- [disagree s0] action `click 7 15` (first-firing clauses [8])
  - predicted: `no change`
  - actual: `(0,15):b>.`

### gravity — missed change (predicted nothing happens) — move (123 cases)

- [disagree s1] action `down` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(15,8):b>. (15,10):.>b`
- [disagree s0] action `left` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(11,0):b>. (13,0):.>b (11,1):b>. (13,1):.>b (15,14):b>. (15,15):b>.`
- [llm s1] action `right` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(0,8):b>. (1,8):b>. (2,8):b>. (0,10):.>b (1,10):.>b (2,10):.>b (15,13):b>. (15,15):.>b`

### gravity — missed change (predicted nothing happens) — noop (18 cases)

- [llm s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,1):b>. (14,1):b>. (13,3):.>b (14,3):.>b`
- [llm s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(15,2):b>. (15,4):.>b (13,10):b>. (14,10):b>. (13,12):.>b (14,12):.>b`
- [llm s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,3):b>. (14,3):b>. (13,5):.>b (14,5):.>b`

### gravity — wrong change — move (35 cases)

- [disagree s0] action `down` (first-firing clauses [])
  - predicted: `(12,1):.>b (13,1):.>b (9,5):b>. (10,5):b>. (9,7):.>b (10,7):.>b (12,14):b>. (13,14):b>.`
  - actual: `(9,5):b>. (11,5):.>b (9,6):b>. (11,6):.>b (12,14):b>. (14,14):.>b (12,15):b>. (14,15):.>b`
- [disagree s0] action `right` (first-firing clauses [])
  - predicted: `(1,3):.>b (15,3):b>. (1,4):.>b (15,4):b>. (13,11):b>. (15,11):.>b (13,12):b>. (15,12):.>b`
  - actual: `(15,3):b>. (15,5):.>b (13,11):b>. (14,11):b>. (13,13):.>b (14,13):.>b`
- [disagree s0] action `down` (first-firing clauses [])
  - predicted: `(7,9):b>. (8,9):b>. (7,11):.>b (8,11):.>b`
  - actual: `(7,9):b>. (9,9):.>b (7,10):b>. (9,10):.>b`

### grow — missed change (predicted nothing happens) — click (96 cases)

- [random s1] action `click 12 12` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(12,12):b>. (12,14):.>b`
- [llm s0] action `click 15 2` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,4):b>. (13,5):.>b (13,6):b>. (13,7):.>b (12,15):b>.`
- [llm s1] action `click 9 15` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,11):b>. (13,12):.>b (14,12):b>. (14,13):.>b`

### grow — missed change (predicted nothing happens) — move (204 cases)

- [llm s1] action `right` (first-firing clauses [4])
  - predicted: `no change`
  - actual: `(12,0):a>. (12,1):a>. (12,2):a>.`
- [disagree s1] action `up` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,9):b>. (13,10):.>b (14,10):b>. (14,11):.>b`
- [disagree_noreset s1] action `up` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,7):b>. (13,8):.>b (14,8):b>. (14,9):.>b`

### grow — missed change (predicted nothing happens) — noop (136 cases)

- [random s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(12,4):.>b`
- [llm s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(11,4):b>. (11,5):.>b`
- [disagree_noreset s1] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(13,9):b>. (13,10):.>b`

### grow — wrong change — move (33 cases)

- [llm s1] action `left` (first-firing clauses [3])
  - predicted: `(12,0):.>a (15,0):a>. (12,1):.>a (15,1):a>. (12,2):.>a (15,2):a>.`
  - actual: `(12,0):.>a (12,1):.>a (12,2):.>a`
- [llm s1] action `left` (first-firing clauses [])
  - predicted: `(13,0):.>a (15,0):a>. (13,1):.>a (15,1):a>. (13,2):.>a (15,2):a>.`
  - actual: `(13,0):.>a (13,1):.>a (13,2):.>a`
- [disagree s1] action `left` (first-firing clauses [3])
  - predicted: `(11,0):.>a (15,0):a>. (11,1):.>a (15,1):a>. (11,2):.>a (15,2):a>.`
  - actual: `(11,0):.>a (15,0):a>. (11,1):.>a (15,1):a>. (11,2):.>a (15,2):a>. (13,3):.>b`

### ice — hallucinated change (nothing actually happens) — move (5 cases)

- [disagree s0] action `up` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `no change`
- [random s0] action `up` (first-firing clauses [])
  - predicted: `(4,14):.>b (4,15):b>.`
  - actual: `no change`
- [disagree s0] action `up` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a`
  - actual: `no change`

### ice — hallucinated change (nothing actually happens) — noop (8 cases)

- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):a>o (0,1):o>a (1,1):o>a`
  - actual: `no change`
- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `no change`
- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `no change`

### ice — missed change (predicted nothing happens) — click (61 cases)

- [random s0] action `click 1 1` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o (4,7):l>b`
- [disagree s1] action `click 10 1` (first-firing clauses [3])
  - predicted: `no change`
  - actual: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a (4,6):b>l`
- [llm s0] action `click 3 10` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a (3,1):b>l (3,3):b>l (3,10):b>l (4,11):b>l`

### ice — missed change (predicted nothing happens) — move (184 cases)

- [llm s1] action `right` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(3,0):a>. (6,0):.>a (4,2):l>. (4,3):.>l (3,9):l>. (3,10):.>l`
- [llm s0] action `right` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(3,0):a>. (6,0):.>a (4,7):l>. (4,8):.>l (3,9):l>. (3,10):.>l`
- [llm s0] action `left` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(3,0):.>a (6,0):a>. (4,5):b>. (4,6):.>b`

### ice — missed change (predicted nothing happens) — noop (110 cases)

- [random s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(3,2):b>. (3,3):.>b`
- [llm s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,7):b>. (4,8):.>b`
- [random s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,3):l>. (4,4):.>l (3,5):l>. (3,6):.>l`

### ice — wrong change — click (81 cases)

- [disagree s0] action `click 3 11` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o (4,1):l>b (4,4):l>b (3,11):l>b`
- [disagree s0] action `click 3 13` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o (6,4):l>b (4,9):l>b (3,13):l>b`
- [random s1] action `click 4 0` (first-firing clauses [])
  - predicted: `(3,0):a>o (4,0):a>o`
  - actual: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o (3,6):l>b`

### ice — wrong change — move (137 cases)

- [disagree s0] action `left` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `(3,0):.>a (6,0):a>. (3,3):l>. (3,4):.>l (4,4):l>. (4,5):.>l`
- [disagree s0] action `down` (first-firing clauses [])
  - predicted: `(0,0):a>o (1,0):a>o (0,1):a>o (1,1):a>o`
  - actual: `(3,1):.>l`
- [disagree s0] action `right` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a`
  - actual: `(2,0):a>. (5,0):.>a`

### ice — wrong change — noop (20 cases)

- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a`
  - actual: `(6,5):b>. (6,6):.>b (4,10):b>. (4,11):.>b (3,14):b>. (3,15):.>b`
- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):o>a (0,1):o>a (1,1):o>a`
  - actual: `(3,4):b>. (3,5):.>b`
- [disagree s0] action `noop` (first-firing clauses [])
  - predicted: `(0,0):o>a (1,0):a>o (0,1):o>a (1,1):o>a`
  - actual: `(4,14):b>. (4,15):.>b`

### magnets — hallucinated change (nothing actually happens) — move (62 cases)

- [disagree s1] action `left` (first-firing clauses [])
  - predicted: `(5,8):.>b (6,8):b>. (5,9):.>b (6,9):b>.`
  - actual: `no change`
- [disagree_noreset s1] action `left` (first-firing clauses [])
  - predicted: `(5,8):.>b (6,8):b>. (5,9):.>b (6,9):b>.`
  - actual: `no change`
- [random s1] action `up` (first-firing clauses [])
  - predicted: `(6,7):.>b (6,9):b>.`
  - actual: `no change`

### magnets — missed change (predicted nothing happens) — move (107 cases)

- [disagree_noreset s0] action `up` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,7):.>b (4,9):b>.`
- [disagree_noreset s0] action `down` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(6,8):b>. (6,10):.>b`
- [disagree s0] action `right` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,7):b>. (5,7):.>b (4,8):b>. (5,8):.>b`

### magnets — wrong change — move (13 cases)

- [disagree_noreset s1] action `right` (first-firing clauses [1, 6])
  - predicted: `(4,8):b>. (5,8):.>b (4,9):b>. (5,9):.>b`
  - actual: `(4,8):b>. (6,8):.>b (4,9):b>. (6,9):.>b`
- [llm s0] action `up` (first-firing clauses [7])
  - predicted: `(5,6):.>b (5,8):b>.`
  - actual: `(6,6):.>b (5,7):b>. (6,7):.>b (5,8):b>.`
- [random s1] action `up` (first-firing clauses [7])
  - predicted: `(5,6):.>b (5,8):b>.`
  - actual: `(6,6):.>b (5,7):b>. (6,7):.>b (5,8):b>.`

### paint — hallucinated change (nothing actually happens) — click (11 cases)

- [disagree s1] action `click 13 4` (first-firing clauses [])
  - predicted: `(13,4):r>g`
  - actual: `no change`
- [disagree_noreset s1] action `click 11 9` (first-firing clauses [])
  - predicted: `(11,9):r>o`
  - actual: `no change`
- [disagree s1] action `click 11 8` (first-firing clauses [])
  - predicted: `(11,8):r>g`
  - actual: `no change`

### paint — missed change (predicted nothing happens) — click (33 cases)

- [disagree_noreset s1] action `click 15 12` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(15,12):g>b`
- [llm s0] action `click 15 12` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(15,12):g>b`
- [random s0] action `click 11 8` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(11,8):r>g`

### paint — wrong change — click (76 cases)

- [disagree s1] action `click 2 10` (first-firing clauses [0])
  - predicted: `(2,10):.>g`
  - actual: `(2,10):.>o`
- [llm s1] action `click 12 6` (first-firing clauses [])
  - predicted: `(12,6):.>r`
  - actual: `(12,6):.>b`
- [llm s1] action `click 1 0` (first-firing clauses [0])
  - predicted: `(1,0):.>r`
  - actual: `(1,0):.>g`

### wind — missed change (predicted nothing happens) — click (52 cases)

- [random s0] action `click 9 9` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(4,4):l>. (8,4):l>. (12,4):l>. (16,4):l>. (5,5):.>l (9,5):.>l (13,5):.>l (9,9):l>. (13,9):l>. (10,10):.>l (14,10):.>l (8,14):l>. (12,14):l>. (16,14):l>. (9,15):.>l (13,15):.>l`
- [disagree s0] action `click 8 1` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(2,5):l>. (6,5):l>. (10,5):l>. (14,5):l>. (3,6):.>l (7,6):.>l (11,6):.>l (15,6):.>l (0,10):l>. (4,10):l>. (8,10):l>. (12,10):l>. (1,11):.>l (5,11):.>l (9,11):.>l (13,11):.>l`
- [disagree s1] action `click 13 1` (first-firing clauses [5])
  - predicted: `no change`
  - actual: `(2,2):.>l (6,2):.>l (10,2):.>l (14,2):.>l`

### wind — missed change (predicted nothing happens) — move (106 cases)

- [llm s1] action `left` (first-firing clauses [5])
  - predicted: `no change`
  - actual: `(2,2):.>l (6,2):.>l (10,2):.>l (14,2):.>l`
- [llm s1] action `up` (first-firing clauses [5])
  - predicted: `no change`
  - actual: `(2,2):.>l (6,2):.>l (10,2):.>l (14,2):.>l`
- [random s1] action `down` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(1,3):l>. (5,3):l>. (9,3):l>. (13,3):l>. (0,4):.>l (4,4):.>l (8,4):.>l (12,4):.>l (0,8):l>. (4,8):l>. (8,8):l>. (3,9):.>l (7,9):.>l (3,13):l>. (7,13):l>. (2,14):.>l (6,14):.>l`

### wind — missed change (predicted nothing happens) — noop (75 cases)

- [disagree_noreset s0] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(3,5):l>. (7,5):l>. (11,5):l>. (2,6):.>l (6,6):.>l (10,6):.>l (2,10):l>. (6,10):l>. (10,10):l>. (1,11):.>l (5,11):.>l (9,11):.>l (0,15):l>. (4,15):l>. (8,15):l>. (12,15):l>. (3,16):.>l (7,16):.>l (11,16):.>l`
- [disagree_noreset s0] action `noop` (first-firing clauses [2])
  - predicted: `no change`
  - actual: `(2,3):l>. (6,3):l>. (10,3):l>. (14,3):l>. (1,4):.>l (5,4):.>l (9,4):.>l (13,4):.>l`
- [llm s1] action `noop` (first-firing clauses [])
  - predicted: `no change`
  - actual: `(0,4):l>. (4,4):l>. (8,4):l>. (12,4):l>. (3,5):.>l (7,5):.>l (11,5):.>l (0,9):l>. (4,9):l>. (8,9):l>. (3,10):.>l (7,10):.>l`

### wind — wrong change — click (45 cases)

- [llm s1] action `click 1 0` (first-firing clauses [])
  - predicted: `(3,5):l>. (7,5):l>. (11,5):l>. (3,6):.>l (7,6):.>l (11,6):.>l (3,10):l>. (7,10):l>. (11,10):l>. (3,11):.>l (7,11):.>l (11,11):.>l`
  - actual: `(3,5):l>. (7,5):l>. (11,5):l>. (2,6):.>l (6,6):.>l (10,6):.>l (3,10):l>. (7,10):l>. (11,10):l>. (2,11):.>l (6,11):.>l (10,11):.>l`
- [disagree_noreset s1] action `click 0 1` (first-firing clauses [])
  - predicted: `(3,5):l>. (7,5):l>. (11,5):l>. (3,6):.>l (7,6):.>l (11,6):.>l (3,10):l>. (7,10):l>. (3,11):.>l (7,11):.>l`
  - actual: `(3,5):l>. (7,5):l>. (11,5):l>. (2,6):.>l (6,6):.>l (10,6):.>l (3,10):l>. (7,10):l>. (2,11):.>l (6,11):.>l`
- [disagree_noreset s1] action `click 15 3` (first-firing clauses [])
  - predicted: `(2,6):l>. (6,6):l>. (10,6):l>. (2,7):.>l (6,7):.>l (10,7):.>l (2,11):l>. (6,11):l>. (2,12):.>l (6,12):.>l`
  - actual: `(2,2):.>l (6,2):.>l (10,2):.>l (14,2):.>l (2,6):l>. (6,6):l>. (10,6):l>. (1,7):.>l (5,7):.>l (9,7):.>l (2,11):l>. (6,11):l>. (1,12):.>l (5,12):.>l`

### wind — wrong change — move (172 cases)

- [disagree_noreset s0] action `right` (first-firing clauses [])
  - predicted: `(2,2):l>. (3,2):.>l (6,2):l>. (7,2):.>l (10,2):l>. (11,2):.>l (14,2):l>. (15,2):.>l (2,7):l>. (3,7):.>l (6,7):l>. (7,7):.>l (10,7):l>. (11,7):.>l (3,12):l>. (4,12):.>l (7,12):l>. (8,12):.>l`
  - actual: `(2,2):l>. (6,2):l>. (10,2):l>. (14,2):l>. (2,3):.>l (6,3):.>l (10,3):.>l (14,3):.>l (2,7):l>. (6,7):l>. (10,7):l>. (2,8):.>l (6,8):.>l (10,8):.>l (3,12):l>. (7,12):l>. (3,13):.>l (7,13):.>l`
- [disagree_noreset s0] action `up` (first-firing clauses [])
  - predicted: `(3,4):.>l (7,4):.>l (11,4):.>l (3,5):l>. (7,5):l>. (11,5):l>. (2,9):.>l (6,9):.>l (2,10):l>. (6,10):l>. (1,14):.>l (1,15):l>.`
  - actual: `(3,5):l>. (7,5):l>. (11,5):l>. (2,6):.>l (6,6):.>l (10,6):.>l (2,10):l>. (6,10):l>. (1,11):.>l (5,11):.>l (1,15):l>. (0,16):.>l`
- [disagree_noreset s0] action `left` (first-firing clauses [])
  - predicted: `(0,3):.>l (1,3):l>. (4,3):.>l (5,3):l>. (8,3):.>l (9,3):l>. (12,3):.>l (13,3):l>. (0,8):l>. (3,8):.>l (4,8):l>. (7,8):.>l (8,8):l>. (11,8):.>l (12,8):l>. (16,8):.>l (1,13):.>l (2,13):l>. (5,13):.>l (6,13):l>. (9,13):.>l `
  - actual: `(1,3):l>. (5,3):l>. (9,3):l>. (13,3):l>. (0,4):.>l (4,4):.>l (8,4):.>l (12,4):.>l (0,8):l>. (4,8):l>. (8,8):l>. (12,8):l>. (3,9):.>l (7,9):.>l (11,9):.>l (2,13):l>. (6,13):l>. (10,13):l>. (14,13):l>. (1,14):.>l (5,14):.>`

### wind — wrong change — noop (19 cases)

- [disagree_noreset s1] action `noop` (first-firing clauses [2])
  - predicted: `(2,3):l>. (6,3):l>. (10,3):l>. (14,3):l>. (2,4):.>l (6,4):.>l (10,4):.>l (14,4):.>l`
  - actual: `(2,3):l>. (6,3):l>. (10,3):l>. (14,3):l>. (1,4):.>l (5,4):.>l (9,4):.>l (13,4):.>l`
- [disagree_noreset s1] action `noop` (first-firing clauses [])
  - predicted: `(3,5):l>. (7,5):l>. (11,5):l>. (3,6):.>l (7,6):.>l (11,6):.>l (2,10):l>. (6,10):l>. (10,10):l>. (2,11):.>l (6,11):.>l (10,11):.>l (0,15):l>. (4,15):l>. (8,15):l>. (12,15):l>. (0,16):.>l (4,16):.>l (8,16):.>l (12,16):.>l`
  - actual: `(3,5):l>. (7,5):l>. (11,5):l>. (2,6):.>l (6,6):.>l (10,6):.>l (2,10):l>. (6,10):l>. (10,10):l>. (1,11):.>l (5,11):.>l (9,11):.>l (0,15):l>. (4,15):l>. (8,15):l>. (12,15):l>. (3,16):.>l (7,16):.>l (11,16):.>l`
- [disagree_noreset s1] action `noop` (first-firing clauses [])
  - predicted: `(2,6):l>. (6,6):l>. (10,6):l>. (2,7):.>l (6,7):.>l (10,7):.>l`
  - actual: `(2,2):.>l (6,2):.>l (10,2):.>l (14,2):.>l (2,6):l>. (6,6):l>. (10,6):l>. (1,7):.>l (5,7):.>l (9,7):.>l`
