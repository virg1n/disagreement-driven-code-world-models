# Results (64 episodes, envs=['disease', 'egg', 'gravity', 'grow', 'ice', 'magnets', 'paint', 'wind'], policies=['disagree', 'llm', 'random', 'disagree_noreset'])

## Overall (mean ± s.e.m. over env×seed episodes)

| metric | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| coverage | 0.673 ± 0.049 | 0.549 ± 0.062 | 0.736 ± 0.063 | 0.767 ± 0.050 |
| ho_acc | 0.465 ± 0.069 | 0.476 ± 0.067 | 0.467 ± 0.064 | 0.455 ± 0.061 |
| ho_acc_chg | 0.227 ± 0.073 | 0.206 ± 0.058 | 0.228 ± 0.059 | 0.150 ± 0.051 |
| ho_oracle | 0.491 ± 0.072 | 0.495 ± 0.070 | 0.489 ± 0.068 | 0.467 ± 0.060 |
| ho_oracle_chg | 0.240 ± 0.072 | 0.251 ± 0.066 | 0.241 ± 0.064 | 0.155 ± 0.052 |
| ho_pool_mean | 0.431 ± 0.063 | 0.440 ± 0.062 | 0.465 ± 0.069 | 0.446 ± 0.060 |
| best_fit | 0.676 ± 0.071 | 0.785 ± 0.057 | 0.787 ± 0.035 | 0.588 ± 0.070 |
| reset_share | 0.016 ± 0.006 | 0.178 ± 0.010 | 0.203 ± 0.013 | 0.000 ± 0.000 |
| noop_share | 0.028 ± 0.011 | 0.073 ± 0.009 | 0.241 ± 0.022 | 0.058 ± 0.013 |
| reset_noop | 0.044 ± 0.013 | 0.252 ± 0.015 | 0.444 ± 0.020 | 0.058 ± 0.013 |
| n_decisions | 39.250 ± 0.310 | 32.625 ± 0.446 | 31.062 ± 0.544 | 40.000 ± 0.000 |
| llm_calls | 194.688 ± 3.172 | 177.312 ± 9.162 | 137.875 ± 9.083 | 193.062 ± 6.629 |
| gen_tokens | 97581.312 ± 4048.994 | 73773.688 ± 5410.533 | 71609.438 ± 5433.370 | 101769.875 ± 5156.315 |
| frac_Hmax0 | 0.088 ± 0.029 | 0.111 ± 0.044 | 0.113 ± 0.048 | 0.248 ± 0.061 |
| frac_blind | 0.074 ± 0.025 | 0.063 ± 0.025 | 0.047 ± 0.014 | 0.186 ± 0.050 |
| cand_unan_wrong | 0.154 ± 0.027 | 0.129 ± 0.023 | 0.090 ± 0.015 | 0.250 ± 0.039 |
| chosen_unan_wrong | 0.036 ± 0.012 | 0.127 ± 0.031 | 0.079 ± 0.014 | 0.081 ± 0.030 |
| mean_H_chosen | 1.488 ± 0.094 | 0.469 ± 0.077 | 0.533 ± 0.055 | 1.248 ± 0.136 |
| ho_unanimous_wrong_of_failed | 0.584 ± 0.089 | 0.469 ± 0.090 | 0.461 ± 0.075 | 0.541 ± 0.087 |
| ho_unanimous_wrong | 0.284 ± 0.062 | 0.252 ± 0.062 | 0.213 ± 0.045 | 0.286 ± 0.057 |
| ho_all_wrong | 0.485 ± 0.072 | 0.490 ± 0.074 | 0.503 ± 0.067 | 0.532 ± 0.060 |
| identity_acc | 0.396 ± 0.060 | 0.396 ± 0.060 | 0.396 ± 0.060 | 0.396 ± 0.060 |

## Paired differences (same env & seed)

| metric | comparison | mean diff | 95% bootstrap CI | wins/ties/losses | sign-test p |
|---|---|---|---|---|---|
| coverage | disagree − llm | +0.124 | [+0.007, +0.240] | 9/4/3 | 0.146 |
| coverage | disagree − random | -0.063 | [-0.178, +0.047] | 4/6/6 | 0.754 |
| coverage | disagree − disagree_noreset | -0.094 | [-0.174, -0.016] | 2/7/7 | 0.180 |
| ho_acc | disagree − llm | -0.011 | [-0.081, +0.068] | 7/0/9 | 0.804 |
| ho_acc | disagree − random | -0.002 | [-0.066, +0.060] | 8/1/7 | 1.000 |
| ho_acc | disagree − disagree_noreset | +0.010 | [-0.064, +0.087] | 9/0/7 | 0.804 |
| ho_acc_chg | disagree − llm | +0.022 | [-0.130, +0.176] | 10/0/6 | 0.454 |
| ho_acc_chg | disagree − random | -0.001 | [-0.123, +0.111] | 9/0/7 | 0.804 |
| ho_acc_chg | disagree − disagree_noreset | +0.077 | [-0.020, +0.202] | 8/2/6 | 0.791 |
| ho_oracle | disagree − llm | -0.004 | [-0.058, +0.047] | 9/0/7 | 0.804 |
| ho_oracle | disagree − random | +0.002 | [-0.076, +0.072] | 8/1/7 | 1.000 |
| ho_oracle | disagree − disagree_noreset | +0.025 | [-0.034, +0.094] | 8/2/6 | 0.791 |
| ho_oracle_chg | disagree − llm | -0.011 | [-0.154, +0.106] | 10/1/5 | 0.302 |
| ho_oracle_chg | disagree − random | -0.001 | [-0.145, +0.123] | 9/1/6 | 0.607 |
| ho_oracle_chg | disagree − disagree_noreset | +0.084 | [-0.013, +0.208] | 8/3/5 | 0.581 |
| reset_noop | disagree − llm | -0.208 | [-0.247, -0.172] | 0/0/16 | 0.000 |
| reset_noop | disagree − random | -0.400 | [-0.448, -0.355] | 0/0/16 | 0.000 |
| reset_noop | disagree − disagree_noreset | -0.014 | [-0.048, +0.023] | 4/3/9 | 0.267 |
| ho_unanimous_wrong | disagree − llm | +0.033 | [-0.092, +0.142] | 11/0/5 | 0.210 |
| ho_unanimous_wrong | disagree − random | +0.071 | [-0.058, +0.189] | 10/1/5 | 0.302 |
| ho_unanimous_wrong | disagree − disagree_noreset | -0.002 | [-0.163, +0.155] | 7/0/9 | 0.804 |

## Per environment (mean over seeds)


**coverage**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 1.00 | 0.67 | 1.00 | 0.92 |
| egg | 0.64 | 0.50 | 0.71 | 0.71 |
| gravity | 0.72 | 1.00 | 0.78 | 0.94 |
| grow | 0.56 | 0.38 | 0.56 | 0.75 |
| ice | 0.50 | 0.50 | 1.00 | 0.75 |
| magnets | 0.62 | 0.44 | 0.50 | 0.56 |
| paint | 0.50 | 0.33 | 0.33 | 0.50 |
| wind | 0.83 | 0.58 | 1.00 | 1.00 |

**ho_acc**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 0.58 | 0.68 | 0.57 | 0.69 |
| egg | 0.66 | 0.56 | 0.69 | 0.49 |
| gravity | 0.32 | 0.33 | 0.30 | 0.31 |
| grow | 0.41 | 0.37 | 0.29 | 0.30 |
| ice | 0.08 | 0.10 | 0.22 | 0.17 |
| magnets | 0.71 | 0.74 | 0.72 | 0.65 |
| paint | 0.77 | 0.85 | 0.80 | 0.83 |
| wind | 0.20 | 0.18 | 0.13 | 0.19 |

**ho_acc_chg**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 0.42 | 0.43 | 0.23 | 0.45 |
| egg | 0.43 | 0.13 | 0.43 | 0.00 |
| gravity | 0.03 | 0.05 | 0.00 | 0.02 |
| grow | 0.11 | 0.05 | 0.05 | 0.00 |
| ice | 0.03 | 0.00 | 0.16 | 0.11 |
| magnets | 0.45 | 0.64 | 0.64 | 0.32 |
| paint | 0.22 | 0.24 | 0.24 | 0.19 |
| wind | 0.13 | 0.11 | 0.06 | 0.12 |

**ho_oracle_chg**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 0.40 | 0.43 | 0.23 | 0.48 |
| egg | 0.43 | 0.41 | 0.58 | 0.00 |
| gravity | 0.04 | 0.06 | 0.01 | 0.02 |
| grow | 0.16 | 0.05 | 0.00 | 0.01 |
| ice | 0.03 | 0.00 | 0.16 | 0.11 |
| magnets | 0.45 | 0.70 | 0.64 | 0.32 |
| paint | 0.28 | 0.24 | 0.24 | 0.19 |
| wind | 0.13 | 0.11 | 0.06 | 0.12 |

**reset_noop**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 0.00 | 0.33 | 0.41 | 0.04 |
| egg | 0.07 | 0.20 | 0.53 | 0.04 |
| gravity | 0.05 | 0.23 | 0.47 | 0.07 |
| grow | 0.06 | 0.30 | 0.44 | 0.06 |
| ice | 0.09 | 0.26 | 0.49 | 0.01 |
| magnets | 0.01 | 0.23 | 0.41 | 0.08 |
| paint | 0.06 | 0.19 | 0.38 | 0.10 |
| wind | 0.00 | 0.29 | 0.43 | 0.06 |

**ho_unanimous_wrong_of_failed**

| env | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|
| disease | 0.13 | 0.45 | 0.34 | 0.49 |
| egg | 0.93 | 0.00 | 0.50 | 0.80 |
| gravity | 0.69 | 0.44 | 0.09 | 0.14 |
| grow | 0.58 | 0.74 | 0.56 | 0.62 |
| ice | 0.81 | 0.68 | 0.54 | 0.31 |
| magnets | 0.87 | 0.47 | 0.35 | 0.52 |
| paint | 0.56 | 0.53 | 0.77 | 0.64 |
| wind | 0.12 | 0.43 | 0.54 | 0.82 |

## Action distribution (share of primitive actions)

| policy | up/down/left/right | click | noop | reset |
|---|---|---|---|---|
| Disagreement | 0.536 | 0.420 | 0.028 | 0.016 |
| LLM-direct | 0.153 | 0.595 | 0.073 | 0.178 |
| Random | 0.287 | 0.269 | 0.241 | 0.203 |
| Disagree (no reset) | 0.489 | 0.453 | 0.058 | 0.000 |

## Final program pool on held-out transitions

| policy | all correct | some correct | all wrong, disagree | all wrong, UNANIMOUS |
|---|---|---|---|---|
| Disagreement | 0.341 | 0.174 | 0.201 | 0.284 |
| LLM-direct | 0.373 | 0.137 | 0.238 | 0.252 |
| Random | 0.432 | 0.065 | 0.289 | 0.213 |
| Disagree (no reset) | 0.405 | 0.064 | 0.245 | 0.286 |

## Per rule (on-clause) on held-out: share of first-firing transitions where the final pool is unanimously wrong

| env | clause | n | Disagreement | LLM-direct | Random | Disagree (no reset) |
|---|---|---|---|---|---|---|
| disease | 0 | 6 | 0.17 | 0.08 | 0.00 | 0.00 |
| disease | 1 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| disease | 2 | 6 | 0.25 | 0.50 | 0.17 | 0.25 |
| disease | 3 | 5 | 0.20 | 0.20 | 0.30 | 0.20 |
| disease | 4 | 6 | 0.00 | 0.25 | 0.17 | 0.17 |
| disease | 5 | 6 | 0.17 | 0.00 | 0.17 | 0.17 |
| egg | 1 | 6 | 0.50 | 0.00 | 0.00 | 0.58 |
| egg | 2 | 6 | 0.50 | 0.00 | 0.00 | 0.75 |
| egg | 3 | 6 | 0.00 | 0.00 | 0.50 | 0.50 |
| egg | 4 | 6 | 0.50 | 0.00 | 0.25 | 0.50 |
| gravity | 0 | 1 | 0.00 | 0.50 | 0.00 | 0.00 |
| gravity | 1 | 3 | 0.17 | 0.17 | 0.00 | 0.00 |
| gravity | 2 | 2 | 0.50 | 0.25 | 0.00 | 0.25 |
| gravity | 3 | 6 | 0.08 | 0.00 | 0.00 | 0.08 |
| gravity | 4 | 6 | 0.50 | 0.00 | 0.00 | 0.42 |
| gravity | 5 | 1 | 1.00 | 1.00 | 0.50 | 0.50 |
| gravity | 6 | 3 | 0.33 | 0.33 | 0.17 | 0.17 |
| gravity | 7 | 2 | 0.50 | 0.50 | 0.25 | 0.25 |
| gravity | 8 | 2 | 1.00 | 1.00 | 0.50 | 0.50 |
| grow | 0 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| grow | 1 | 4 | 0.75 | 0.75 | 0.50 | 0.88 |
| grow | 2 | 4 | 0.75 | 0.75 | 0.50 | 0.88 |
| grow | 3 | 6 | 0.25 | 0.83 | 0.50 | 0.50 |
| grow | 4 | 6 | 0.08 | 0.50 | 0.00 | 0.50 |
| grow | 5 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| grow | 7 | 6 | 0.00 | 0.00 | 0.42 | 0.00 |
| ice | 0 | 6 | 1.00 | 1.00 | 0.17 | 0.25 |
| ice | 1 | 6 | 0.50 | 1.00 | 0.17 | 0.50 |
| ice | 2 | 6 | 0.50 | 0.33 | 0.08 | 0.50 |
| ice | 3 | 6 | 0.83 | 0.50 | 0.42 | 0.00 |
| magnets | 0 | 6 | 0.50 | 0.17 | 0.33 | 0.17 |
| magnets | 1 | 6 | 0.50 | 0.00 | 0.08 | 0.25 |
| magnets | 2 | 6 | 0.50 | 0.08 | 0.17 | 0.25 |
| magnets | 3 | 6 | 0.50 | 0.00 | 0.00 | 0.42 |
| magnets | 4 | 2 | 0.50 | 0.50 | 0.50 | 0.25 |
| magnets | 6 | 2 | 1.00 | 0.25 | 0.25 | 0.75 |
| magnets | 7 | 1 | 1.00 | 0.50 | 1.00 | 0.50 |
| paint | 0 | 6 | 0.42 | 0.17 | 0.33 | 0.42 |
| paint | 1 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| paint | 2 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| paint | 3 | 5 | 0.00 | 0.00 | 0.00 | 0.00 |
| paint | 4 | 2 | 0.00 | 0.00 | 0.00 | 0.00 |
| wind | 0 | 6 | 0.00 | 0.00 | 0.00 | 0.00 |
| wind | 1 | 5 | 0.30 | 0.60 | 0.60 | 0.90 |
| wind | 2 | 6 | 0.08 | 0.33 | 0.50 | 0.58 |
| wind | 3 | 6 | 0.00 | 0.17 | 0.33 | 0.50 |
| wind | 4 | 5 | 0.20 | 0.50 | 0.50 | 0.80 |
| wind | 5 | 6 | 1.00 | 1.00 | 1.00 | 1.00 |

## Exposure of shared wrong assumptions during exploration

Decisions where the executed action had a unanimous-but-wrong pool prediction (the only way a shared error gets exposed), and decisions where no candidate had any disagreement (H_max = 0).

| policy | decisions | chosen unanimous-wrong (exposures) | H_max = 0 | H_max = 0 while some candidate unanimous-wrong (blind spot) | candidates unanimous-wrong |
|---|---|---|---|---|---|
| Disagreement | 628 | 0.037 | 0.088 | 0.075 | 0.157 |
| LLM-direct | 522 | 0.130 | 0.115 | 0.063 | 0.133 |
| Random | 497 | 0.078 | 0.117 | 0.048 | 0.091 |
| Disagree (no reset) | 640 | 0.081 | 0.248 | 0.186 | 0.251 |
