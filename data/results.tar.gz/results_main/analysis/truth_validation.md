# Ground-truth audit for /public/bsuvernev2_autumn/results_main

| statistic | disagree | llm | random | disagree_noreset |
|---|---|---|---|---|
| candidates contaminated | 0.079 | 0.036 | 0.018 | 0.128 |
| decisions with contaminated chosen action | 0.137 | 0.053 | 0.018 | 0.125 |
| [clean] candidates unanimous-wrong | 0.115 | 0.111 | 0.085 | 0.175 |
| [clean] decisions where a shared error is exposable | 0.513 | 0.477 | 0.399 | 0.473 |
| [clean] executed actions refuting >=1 program | 0.942 | 0.435 | 0.448 | 0.834 |
| [clean] candidates unanimous-wrong, actions 1-13 | 0.058 | 0.086 | 0.026 | 0.077 |
| [clean] candidates unanimous-wrong, actions 14-27 | 0.127 | 0.113 | 0.083 | 0.205 |
| [clean] candidates unanimous-wrong, actions 28-40 | 0.169 | 0.140 | 0.147 | 0.300 |
| [clean] P(expose | exposable) | 0.052 | 0.204 | 0.218 | 0.117 |

Contaminated candidate share by environment: disease 0.000, egg 0.223, gravity 0.073, grow 0.000, ice 0.014, magnets 0.212, paint 0.000, wind 0.000
